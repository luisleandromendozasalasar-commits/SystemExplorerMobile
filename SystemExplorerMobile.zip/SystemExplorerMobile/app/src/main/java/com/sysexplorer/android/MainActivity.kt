package com.sysexplorer.android

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.format.DateUtils
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                App()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        topBar = { TopAppBar(title = { Text("System Explorer Mobile") }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Home, null) }, label = { Text("Resumen") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.AutoMirrored.Filled.List, null) }, label = { Text("Apps") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.Info, null) }, label = { Text("Dispositivo") })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> SummaryScreen()
                1 -> AppsScreen()
                else -> DeviceScreen()
            }
        }
    }
}

@Composable
fun InfoCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
fun BarRow(label: String, detail: String, progress: Float) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text(detail, style = MaterialTheme.typography.bodySmall)
        }
        LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun KeyValue(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.width(12.dp))
        Text(v, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f, fill = false))
    }
}

@Composable
fun SummaryScreen() {
    val ctx = LocalContext.current
    var snap by remember { mutableStateOf<Snapshot?>(null) }
    var rxRate by remember { mutableLongStateOf(0L) }
    var txRate by remember { mutableLongStateOf(0L) }

    LaunchedEffect(Unit) {
        var prev: Snapshot? = null
        var prevT = System.currentTimeMillis()
        while (true) {
            val s = withContext(Dispatchers.IO) { SystemInfo.snapshot(ctx) }
            val now = System.currentTimeMillis()
            val p = prev
            if (p != null && now > prevT) {
                val dt = (now - prevT) / 1000.0
                rxRate = ((s.rxBytes - p.rxBytes) / dt).toLong().coerceAtLeast(0)
                txRate = ((s.txBytes - p.txBytes) / dt).toLong().coerceAtLeast(0)
            }
            prev = s
            prevT = now
            snap = s
            delay(2000)
        }
    }

    val s = snap
    if (s == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
        InfoCard("Memoria RAM") {
            BarRow("En uso", "${formatBytes(s.mem.used)} / ${formatBytes(s.mem.total)}", s.mem.pct)
        }
        InfoCard("Almacenamiento") {
            BarRow("Usado", "${formatBytes(s.storage.used)} / ${formatBytes(s.storage.total)}", s.storage.pct)
        }
        InfoCard("CPU (${s.cpu.cores} núcleos)") {
            KeyValue("Chip", s.cpu.hardware)
            KeyValue("Arquitectura", s.cpu.abi)
            s.cpu.freqsMhz.forEachIndexed { i, f ->
                KeyValue("Núcleo $i", if (f > 0) "$f MHz" else "No disponible")
            }
        }
        InfoCard("Batería") {
            BarRow("Nivel", "${s.battery.level}%", s.battery.level / 100f)
            KeyValue("Estado", s.battery.status)
            KeyValue("Salud", s.battery.health)
            KeyValue("Temperatura", String.format("%.1f °C", s.battery.tempC))
            KeyValue("Voltaje", "${s.battery.voltageMv} mV")
        }
        InfoCard("Red") {
            KeyValue("Conexión", s.net.type)
            KeyValue("Bajada (enlace)", "${s.net.downKbps / 1000} Mbps")
            KeyValue("Subida (enlace)", "${s.net.upKbps / 1000} Mbps")
            KeyValue("Velocidad actual ↓", "${formatBytes(rxRate)}/s")
            KeyValue("Velocidad actual ↑", "${formatBytes(txRate)}/s")
            KeyValue("Recibido total", formatBytes(s.rxBytes))
            KeyValue("Enviado total", formatBytes(s.txBytes))
        }
        InfoCard("Sistema") {
            KeyValue("Tiempo encendido", formatDuration(s.uptimeMs))
        }
    }
}

@Composable
fun AppIcon(pkg: String) {
    val pm = LocalContext.current.packageManager
    val bmp by produceState<ImageBitmap?>(null, pkg) {
        value = withContext(Dispatchers.IO) {
            try { pm.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() } catch (e: Exception) { null }
        }
    }
    val b = bmp
    if (b != null) Image(bitmap = b, contentDescription = null, modifier = Modifier.size(40.dp))
    else Spacer(Modifier.size(40.dp))
}

@Composable
fun AppsScreen() {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppItem>?>(null) }
    var hasUsage by remember { mutableStateOf(SystemInfo.hasUsageAccess(ctx)) }
    var reload by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var showSystem by remember { mutableStateOf(false) }
    var sort by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<AppItem?>(null) }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                hasUsage = SystemInfo.hasUsageAccess(ctx)
                reload++
            }
        }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs) }
    }
    LaunchedEffect(reload) {
        apps = withContext(Dispatchers.IO) { SystemInfo.loadApps(ctx) }
    }

    val list = remember(apps, query, showSystem, sort) {
        val base = (apps ?: emptyList())
            .filter { showSystem || !it.isSystem }
            .filter { query.isBlank() || it.name.contains(query, true) || it.pkg.contains(query, true) }
        when (sort) {
            1 -> base.sortedByDescending { it.sizeBytes }
            2 -> base.sortedByDescending { it.lastUsed }
            else -> base.sortedBy { it.name.lowercase() }
        }
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            label = { Text("Buscar app") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        )
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(sort == 0, { sort = 0 }, { Text("Nombre") })
            FilterChip(sort == 1, { sort = 1 }, { Text("Tamaño") })
            FilterChip(sort == 2, { sort = 2 }, { Text("Uso reciente") })
        }
        Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Switch(showSystem, { showSystem = it })
            Spacer(Modifier.width(8.dp))
            Text("Mostrar apps del sistema (${list.size})")
        }
        if (!hasUsage) {
            Card(Modifier.fillMaxWidth().padding(12.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Activa el acceso de uso para ver cuándo se usó cada app y su tiempo en pantalla.")
                    TextButton(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }) { Text("Dar acceso") }
                }
            }
        }
        if (apps == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.pkg }) { app ->
                    Row(
                        Modifier.fillMaxWidth().clickable { selected = app }.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(app.pkg)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(app.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(app.pkg, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(formatBytes(app.sizeBytes), style = MaterialTheme.typography.bodySmall)
                            if (hasUsage) {
                                Text(
                                    if (app.lastUsed > 0)
                                        DateUtils.getRelativeTimeSpanString(app.lastUsed, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()
                                    else "—",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }

    selected?.let { app -> AppDialog(app, ctx, hasUsage) { selected = null } }
}

@Composable
fun AppDialog(app: AppItem, ctx: Context, hasUsage: Boolean, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(app.name) },
        text = {
            Column {
                Text(app.pkg, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                KeyValue("Tamaño del APK", formatBytes(app.sizeBytes))
                KeyValue("Tipo", if (app.isSystem) "Sistema" else "Usuario")
                if (hasUsage) KeyValue("Tiempo en pantalla (30 días)", formatDuration(app.foregroundMs))
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = {
                    ctx.packageManager.getLaunchIntentForPackage(app.pkg)?.let {
                        ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                    onDismiss()
                }) { Text("Abrir") }
                TextButton(onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    onDismiss()
                }) { Text("Info / Forzar detención") }
                if (!app.isSystem) {
                    TextButton(onClick = {
                        ctx.startActivity(
                            Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                        onDismiss()
                    }) { Text("Desinstalar") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

@Composable
fun DeviceScreen() {
    val ctx = LocalContext.current
    val dm = ctx.resources.displayMetrics
    val rows = listOf(
        "Fabricante" to Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
        "Modelo" to Build.MODEL,
        "Dispositivo" to Build.DEVICE,
        "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
        "Parche de seguridad" to (Build.VERSION.SECURITY_PATCH ?: "?"),
        "Kernel" to (System.getProperty("os.version") ?: "?"),
        "ABIs" to Build.SUPPORTED_ABIS.joinToString(", "),
        "Pantalla" to "${dm.widthPixels}x${dm.heightPixels} px, ${dm.densityDpi} dpi",
        "Build" to Build.DISPLAY,
        "Huella (fingerprint)" to Build.FINGERPRINT
    )
    Column(Modifier.verticalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
        InfoCard("Información del dispositivo") {
            rows.forEach { (k, v) -> KeyValue(k, v) }
        }
        InfoCard("Nota") {
            Text(
                "Android no permite a una app normal ver ni cerrar los procesos de otras apps. " +
                    "Para eso se necesita root o Shizuku. Aquí se usa el acceso de uso y la información de apps instaladas.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
