package com.sysexplorer.android

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import android.net.TrafficStats
import java.io.File

data class MemInfo(val total: Long, val used: Long) {
    val pct: Float get() = if (total > 0) used.toFloat() / total else 0f
}

data class StorageInfo(val total: Long, val used: Long) {
    val pct: Float get() = if (total > 0) used.toFloat() / total else 0f
}

data class BatteryInfo(
    val level: Int,
    val status: String,
    val tempC: Float,
    val voltageMv: Int,
    val health: String
)

data class CpuInfo(val cores: Int, val abi: String, val hardware: String, val freqsMhz: List<Long>)

data class NetInfo(val type: String, val downKbps: Int, val upKbps: Int)

data class Snapshot(
    val mem: MemInfo,
    val storage: StorageInfo,
    val battery: BatteryInfo,
    val cpu: CpuInfo,
    val net: NetInfo,
    val rxBytes: Long,
    val txBytes: Long,
    val uptimeMs: Long
)

data class AppItem(
    val name: String,
    val pkg: String,
    val isSystem: Boolean,
    val sizeBytes: Long,
    val lastUsed: Long,
    val foregroundMs: Long
)

object SystemInfo {

    fun snapshot(ctx: Context) = Snapshot(
        mem = memory(ctx),
        storage = storage(),
        battery = battery(ctx),
        cpu = cpu(),
        net = network(ctx),
        rxBytes = TrafficStats.getTotalRxBytes(),
        txBytes = TrafficStats.getTotalTxBytes(),
        uptimeMs = SystemClock.elapsedRealtime()
    )

    private fun memory(ctx: Context): MemInfo {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return MemInfo(mi.totalMem, mi.totalMem - mi.availMem)
    }

    private fun storage(): StorageInfo {
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.blockCountLong * st.blockSizeLong
        val free = st.availableBlocksLong * st.blockSizeLong
        return StorageInfo(total, total - free)
    }

    private fun battery(ctx: Context): BatteryInfo {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = when (i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Cargando"
            BatteryManager.BATTERY_STATUS_FULL -> "Completa"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Descargando"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "No carga"
            else -> "Desconocido"
        }
        val health = when (i?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Buena"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Sobrecalentada"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dañada"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Sobrevoltaje"
            BatteryManager.BATTERY_HEALTH_COLD -> "Fría"
            else -> "Desconocida"
        }
        return BatteryInfo(
            level = if (level >= 0) level * 100 / scale else -1,
            status = status,
            tempC = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f,
            voltageMv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0,
            health = health
        )
    }

    private fun cpu(): CpuInfo {
        val cores = Runtime.getRuntime().availableProcessors()
        val freqs = (0 until cores).map { n ->
            try {
                File("/sys/devices/system/cpu/cpu$n/cpufreq/scaling_cur_freq")
                    .readText().trim().toLong() / 1000
            } catch (e: Exception) {
                0L
            }
        }
        val hw = if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank() && Build.SOC_MODEL != "unknown")
            Build.SOC_MODEL else Build.HARDWARE
        return CpuInfo(cores, Build.SUPPORTED_ABIS.firstOrNull() ?: "?", hw, freqs)
    }

    private fun network(ctx: Context): NetInfo {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            ?: return NetInfo("Sin conexión", 0, 0)
        val type = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Datos móviles"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "Otra"
        }
        return NetInfo(type, caps.linkDownstreamBandwidthKbps, caps.linkUpstreamBandwidthKbps)
    }

    @Suppress("DEPRECATION")
    fun hasUsageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun loadApps(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val usage = if (hasUsageAccess(ctx)) {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis()
            usm.queryAndAggregateUsageStats(end - 30L * 24 * 3600 * 1000, end)
        } else emptyMap()

        return pm.getInstalledApplications(0).map { ai ->
            val u = usage[ai.packageName]
            AppItem(
                name = try { pm.getApplicationLabel(ai).toString() } catch (e: Exception) { ai.packageName },
                pkg = ai.packageName,
                isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                sizeBytes = try { File(ai.sourceDir).length() } catch (e: Exception) { 0L },
                lastUsed = u?.lastTimeUsed ?: 0L,
                foregroundMs = u?.totalTimeInForeground ?: 0L
            )
        }
    }
}

fun formatBytes(b: Long): String {
    if (b < 1024) return "$b B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = -1
    while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
    return String.format("%.1f %s", v, units[i])
}

fun formatDuration(ms: Long): String {
    val s = ms / 1000
    val d = s / 86400
    val h = (s % 86400) / 3600
    val m = (s % 3600) / 60
    return if (d > 0) "${d}d ${h}h ${m}m" else "${h}h ${m}m"
}
