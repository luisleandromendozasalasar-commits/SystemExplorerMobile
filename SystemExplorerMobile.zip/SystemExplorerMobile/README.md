# System Explorer Mobile

1. Abre la carpeta en Android Studio (Koala o superior, JDK 17).
2. Espera el Gradle Sync (descarga Gradle 8.7 y dependencias).
3. Run ▶ en un móvil o emulador (Android 8.0+), o Build > Build APK(s).

Pestañas: Resumen (RAM, almacenamiento, CPU, batería, red en vivo), Apps (buscar, ordenar, abrir, info, desinstalar, uso reciente) y Dispositivo.

## Generar el APK sin Android Studio
Sube esta carpeta a un repositorio de GitHub. En la pestaña Actions se ejecuta "Build APK" y al terminar descargas app-debug.apk desde Artifacts.
